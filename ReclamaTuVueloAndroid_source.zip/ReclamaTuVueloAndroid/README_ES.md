# ReclamaTuVuelo — proyecto Android inicial

Este proyecto envuelve el prototipo web en una aplicación Android sencilla que funciona sin conexión para generar el borrador de la reclamación.

## Importante
- Esto es el **código fuente del proyecto**, no un APK/AAB firmado ni una publicación en Google Play.
- No envía reclamaciones a aerolíneas ni guarda datos en un servidor.
- Antes de publicar, prueba en dispositivos reales, revisa accesibilidad, privacidad, política de datos y los requisitos vigentes de Google Play.
- La aplicación debe pasar por las pruebas y verificaciones que Google solicite para la cuenta de desarrollador.
- El identificador de paquete inicial es `com.reclamatuvuelo.app`. Debe comprobarse que esté disponible y no cambiarse después de publicar.
- El proyecto usa `compileSdk = 36` y `targetSdk = 36`. Android Studio puede pedir instalar Android SDK Platform 36 y componentes de compilación.

## Abrir y ejecutar
1. Instala Android Studio estable y JDK 17.
2. En Android Studio, selecciona **Open** y elige la carpeta `ReclamaTuVueloAndroid`.
3. Acepta la sincronización de Gradle e instala Android SDK Platform 36 si te lo solicita.
4. Conecta un teléfono Android con depuración USB o crea un emulador.
5. Pulsa **Run** para instalar una versión de prueba.

## Crear el paquete para Google Play
1. Revisa y prueba todos los flujos en un dispositivo.
2. En Android Studio, abre **Build > Generate Signed Bundle / APK**.
3. Selecciona **Android App Bundle (AAB)** y crea/elige una clave de firma. Guarda la clave y contraseñas de forma segura; no las compartas.
4. Genera el bundle de release.
5. En Google Play Console, crea la app, completa los datos de la ficha, declaración de seguridad de datos, política de privacidad, clasificación de contenido y demás formularios aplicables.
6. Configura el precio de pago que quieras, sujeto a las opciones y condiciones de Google Play.
7. Sube el AAB a una pista de prueba. Completa cualquier requisito de prueba para cuentas nuevas y corrige los errores de revisión antes de solicitar publicación.

## Próximas mejoras recomendadas antes de cobrar
- Política de privacidad pública y contacto de soporte.
- Pruebas de accesibilidad, compatibilidad y seguridad.
- Validación jurídica del contenido para Colombia.
- Aclarar en la ficha que la app genera borradores y no garantiza compensaciones ni radica automáticamente las reclamaciones.
- Decidir si realmente conviene cobrar por descarga o usar una versión gratuita de prueba.
